# Install Requirements
pip3 install -r requirements.txt

# Set environment variable to contain secret 
export API_KEY_SECRET=<uuid> 

# Run
python3 create_jwt.py
